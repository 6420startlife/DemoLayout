package com.ptithcm.thuan6420.basecleanarchitecture.data.datasources.api

data class RequestRegister (val email : String, val password : String, val name : String, val phone_number : Number)