package com.ptithcm.thuan6420.basecleanarchitecture.data.datasources.api

data class ResponseRegister(
    val message: String,
    val status: Int
)