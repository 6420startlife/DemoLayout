package com.ptithcm.thuan6420.basecleanarchitecture.ui.login.view.login

data class LoginFormState (
    var emailError : String? = null,
    var passwordError : String? = null,
    var isDataValid : Boolean = false)