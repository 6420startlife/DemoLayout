package com.ptithcm.thuan6420.basecleanarchitecture.data.datasources.api

data class RequestLogin(val email : String, val password : String)