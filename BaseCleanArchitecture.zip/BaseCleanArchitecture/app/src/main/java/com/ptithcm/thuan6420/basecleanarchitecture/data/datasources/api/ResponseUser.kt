package com.ptithcm.thuan6420.basecleanarchitecture.data.datasources.api

data class ResponseUser(
    val email: String,
    val id: Int,
    val name: String,
    val phone_number: String
)
