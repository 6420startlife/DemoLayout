package com.ptithcm.thuan6420.basecleanarchitecture.ui.login.view.login

data class LoginResult(var status : Boolean = false, var message : String? = null)
