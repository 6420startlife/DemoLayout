package com.ptithcm.thuan6420.basecleanarchitecture.ui.utility

data class InvalidField(val idField : Byte, var message : String?)
