package com.ptithcm.thuan6420.basecleanarchitecture.data.datasources.sharepreferences

import android.content.Context
import com.ptithcm.thuan6420.basecleanarchitecture.ui.utility.ConstantMessage.USER_SHARED_PREFERENCES

class MySharedPreferences(val context: Context) {

    fun putSharedPreferencesValue(key: String?, value: String?) {
        val sharedPreferences = context.getSharedPreferences(
            USER_SHARED_PREFERENCES,
            Context.MODE_PRIVATE
        )
        val editor = sharedPreferences.edit()
        editor.putString(key, value)
        editor.apply()
    }

    fun getSharedPreferencesValue(key: String?): String? {
        val sharedPreferences = context.getSharedPreferences(
            USER_SHARED_PREFERENCES,
            Context.MODE_PRIVATE
        )
        return sharedPreferences.getString(key, "")
    }
}