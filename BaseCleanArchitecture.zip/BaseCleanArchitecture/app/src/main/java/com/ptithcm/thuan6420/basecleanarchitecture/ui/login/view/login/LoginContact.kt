package com.ptithcm.thuan6420.basecleanarchitecture.ui.login.view.login

interface LoginContact {
    interface PresenterInterface{
        fun onLogin()
    }
    interface ViewInterface{

    }
}