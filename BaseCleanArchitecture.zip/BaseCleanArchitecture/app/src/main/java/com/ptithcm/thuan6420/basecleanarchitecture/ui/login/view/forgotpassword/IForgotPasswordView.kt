package com.ptithcm.thuan6420.basecleanarchitecture.ui.login.view.forgotpassword

interface IForgotPasswordView {
    fun navigateToLogin()
}