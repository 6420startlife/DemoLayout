package com.ptithcm.thuan6420.basecleanarchitecture.ui.dialogs

interface DialogListener {
    fun onClickButtonOK()
}