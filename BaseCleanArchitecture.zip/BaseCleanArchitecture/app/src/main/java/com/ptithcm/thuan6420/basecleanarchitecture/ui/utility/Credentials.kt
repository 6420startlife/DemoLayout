package com.ptithcm.thuan6420.basecleanarchitecture.ui.utility

object Credentials {
    const val REGEX_PHONE_NUMBER = "^[0]{1}\\d{9}$"
}