package com.ptithcm.thuan6420.basecleanarchitecture.ui.login.viewmodel

import android.util.Patterns
import androidx.databinding.Bindable
import androidx.databinding.Observable
import androidx.lifecycle.*
import com.ptithcm.thuan6420.basecleanarchitecture.data.repositories.UserRepository
import com.ptithcm.thuan6420.basecleanarchitecture.ui.login.model.User
import com.ptithcm.thuan6420.basecleanarchitecture.ui.utility.ConstantMessage
import com.ptithcm.thuan6420.basecleanarchitecture.ui.utility.Credentials
import kotlinx.coroutines.launch
import java.util.regex.Pattern

class UserViewModel(private val repository: UserRepository) : ViewModel(), Observable {
    @Bindable
    val inputEmail = MutableLiveData<String>()
    @Bindable
    val errorEmail = MutableLiveData<String?>()
    @Bindable
    val inputPassword = MutableLiveData<String>()
    @Bindable
    val errorPassword = MutableLiveData<String?>()
    @Bindable
    val inputFullName = MutableLiveData<String>()
    @Bindable
    val errorFullName = MutableLiveData<String?>()
    @Bindable
    val inputPhoneNumber = MutableLiveData<String>()
    @Bindable
    val errorPhoneNumber = MutableLiveData<String?>()
    @Bindable
    val isUpdating = MutableLiveData(false)

    fun createUser(user: User) = viewModelScope.launch {
        isUpdating.postValue(true)
        repository.createUser(user)
        isUpdating.postValue(false)
    }

    fun login() {
        isUpdating.postValue(true)
        isUpdating.postValue(false)
    }

    fun validate(lifecycleOwner: LifecycleOwner) {
        inputEmail.observe(lifecycleOwner, Observer {
            if (inputEmail.value?.isEmpty() == true) {
                errorEmail.postValue(ConstantMessage.MESSAGE_EMPTY_EMAIL)
            } else if (!Patterns.EMAIL_ADDRESS.matcher(inputEmail.value.toString()).matches()) {
                errorEmail.postValue(ConstantMessage.MESSAGE_INVALID_EMAIL)
            } else {
                errorEmail.postValue(null)
            }
        })
        inputPassword.observe(lifecycleOwner, Observer {
            if (inputPassword.value?.isEmpty() == true) {
                errorPassword.postValue(ConstantMessage.MESSAGE_EMPTY_PASSWORD)
            } else if (inputPassword.value?.length!! < 9) {
                errorPassword.postValue(ConstantMessage.MESSAGE_INVALID_PASSWORD)
            } else {
                errorPassword.postValue(null)
            }
        })
        inputFullName.observe(lifecycleOwner, Observer {
            if (inputFullName.value?.isEmpty() == true) {
                errorFullName.postValue(ConstantMessage.MESSAGE_EMPTY_FULL_NAME)
            } else {
                errorFullName.postValue(null)
            }
        })
        inputPhoneNumber.observe(lifecycleOwner, Observer {
            if (inputPhoneNumber.value?.isEmpty() == true) {
                errorPhoneNumber.postValue(ConstantMessage.MESSAGE_EMPTY_EMAIL)
            } else if (!Pattern.compile(Credentials.REGEX_PHONE_NUMBER).matcher(inputPhoneNumber.value.toString()).matches()) {
                errorPhoneNumber.postValue(ConstantMessage.MESSAGE_INVALID_EMAIL)
            } else {
                errorPhoneNumber.postValue(null)
            }
        })
    }

    override fun addOnPropertyChangedCallback(callback: Observable.OnPropertyChangedCallback?) {

    }

    override fun removeOnPropertyChangedCallback(callback: Observable.OnPropertyChangedCallback?) {

    }
}